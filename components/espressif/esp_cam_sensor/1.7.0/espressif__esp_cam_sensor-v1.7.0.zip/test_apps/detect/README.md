| Supported Targets | ESP32-P4 | ESP32-S3 | ESP32-C5 | ESP32-C6 | ESP32-C3 |
| ----------------- | ----- | ----- | ----- | ----- | ----- |
