# ESP LCD SH1107

[![Component Registry](https://components.espressif.com/components/espressif/esp_lcd_sh1107/badge.svg)](https://components.espressif.com/components/espressif/esp_lcd_sh1107)

Implementation of the SH1107 LCD controller with esp_lcd component.

| LCD controller | Communication interface | Component name | Link to datasheet |
| :------------: | :---------------------: | :------------: | :---------------: |
| SH1107         | I2C                     | esp_lcd_sh1107 | [WIKI](https://www.waveshare.com/wiki/1.3inch_OLED_Module_(C)) |

## Add to project

Packages from this repository are uploaded to [Espressif's component service](https://components.espressif.com/).
You can add them to your project via `idf.py add-dependancy`, e.g.
```
    idf.py add-dependency esp_lcd_sh1107==1.0.0
```

Alternatively, you can create `idf_component.yml`. More is in [Espressif's documentation](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-guides/tools/idf-component-manager.html).

## Usage

For detailed usage, please go to [LCD documentation](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/peripherals/lcd.html).

## Example initialization

```
i2c_master_bus_handle_t i2c_handle = NULL;
const i2c_master_bus_config_t i2c_config = {
    .i2c_port = EXAMPLE_I2C_NUM,
    .sda_io_num = EXAMPLE_I2C_SDA,
    .scl_io_num = EXAMPLE_I2C_SCL,
    .clk_source = I2C_CLK_SRC_DEFAULT,
};
BSP_ERROR_CHECK_RETURN_ERR(i2c_new_master_bus(&i2c_config, &i2c_handle));

esp_lcd_panel_io_handle_t io_handle = NULL;
esp_lcd_panel_io_i2c_config_t io_config = ESP_LCD_IO_I2C_SH1107_CONFIG();
ESP_ERROR_CHECK(esp_lcd_new_panel_io_i2c(i2c_handle, &io_config, &io_handle));

esp_lcd_panel_handle_t lcd_panel_handle = NULL;
esp_lcd_panel_dev_config_t panel_config = {
    .bits_per_pixel = 1,
    .reset_gpio_num = BOARD_DISP_I2C_RST,
};
ESP_ERROR_CHECK(esp_lcd_new_panel_sh1107(io_handle, &panel_config, &lcd_panel_handle));

ESP_ERROR_CHECK(esp_lcd_panel_reset(lcd_panel_handle));
ESP_ERROR_CHECK(esp_lcd_panel_init(lcd_panel_handle));
ESP_ERROR_CHECK(esp_lcd_panel_disp_on_off(lcd_panel_handle, true));
```

## Rotation and LVGL usage

For using this LCD display with LVGL or when you want to use rotation (only with LVGL), please use [`esp_lvgl_port`](
https://github.com/espressif/esp-bsp/tree/master/components/esp_lvgl_port) component.
