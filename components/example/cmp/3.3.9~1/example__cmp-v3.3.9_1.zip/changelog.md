## 3.3.9

- Add more fields to the manifest of `cmp`

## 3.3.8

- Add example

## 3.3.7

- Fix accidentally excluded header file

## 3.3.6

- Add repository url and description

## 3.3.5

- Fix function declaration isn't a prototype

## 3.3.4

- Fix function prototype

## 3.3.3

- Add use cases to the readme
- Add license
